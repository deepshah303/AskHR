package repo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bean.ForgetBean;
import bean.LoginBean;
import entity.Employee;
import entity.Project;

@Repository
public class UserRepoImpl implements UserRepo {

	@Autowired
	private SessionFactory factory;

	@Override
	public Employee authenticate(LoginBean login) {
		Session session = factory.openSession();
		Employee emp = (Employee) session.get(Employee.class, login.getEmpId());
		if(emp==null)
			System.out.println("null");
		else {
		System.out.println(emp.getEmpId());
		System.out.println(login.getEmpId()+" "+login.getEmpPassword());
		if (emp.getEmpPassword().equals(login.getEmpPassword()))
			return emp;
		
		else
			return null;
	}
		return null;
		}

	@Override
	public boolean validate(ForgetBean forget) {
		Session session = factory.openSession();
		Employee emp = (Employee) session.get(Employee.class, forget.getEmpId());
		if (emp.getEmpSecurityAns().equalsIgnoreCase(forget.getAnswer()))
			return true;
		else
			return false;
	}

	@Override
	public boolean changePass(LoginBean user) {
		Session session = factory.openSession();
		Transaction trx = session.beginTransaction();
		try {
			Employee employee = (Employee) session.get(Employee.class, user.getEmpId());
			employee.setEmpPassword(user.getEmpPassword());
			session.save(employee);
			trx.commit();
			return true;
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public int getSal(int id) {
		Session session = factory.openSession();
		Employee emp=(Employee)session.get(Employee.class, id);
		return emp.getEmpSalary();
	}

	@Override
	public List<Project> viewProjects() {
		Session session = factory.openSession();
		String hql = "from Project where LOWER(status)='open'";
		List<Project> projList= session.createQuery(hql).list();
		session.close();
		return projList;
	}
}
