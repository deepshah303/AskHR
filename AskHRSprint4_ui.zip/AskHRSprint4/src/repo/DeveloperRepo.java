package repo;

import java.util.List;

import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.ProjectApplication;

public interface DeveloperRepo {

	boolean applyLeave(Leave leave);

	

	List<Leave> viewLeaveStatus(int employeeId);
	
	boolean giveFeedback(Feedback feedback);

	List<Feedback> getMyFeedback(int empId);

	List<Announcement> getAnnouncements();

	List<Announcement> empDashAnnouncement();

	boolean applyProject(int projectId, Employee employee);



	List<ProjectApplication> viewApplicationStatus(Employee employee);

}
