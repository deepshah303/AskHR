package repo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.Project;
import entity.ProjectApplication;

@Repository
public class DeveloperRepoImpl implements DeveloperRepo {

	@Autowired
	private SessionFactory factory;
	
	@Override
	public boolean applyLeave(Leave leave) {
		Session session=factory.openSession();
		Transaction trx=session.beginTransaction();
		
		try {
			session.save(leave);
			trx.commit();
			return true;
		} catch (Exception e) {
			trx.rollback();
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public List<Leave> viewLeaveStatus(int employeeId) {
		Session session=factory.openSession();
		String hql="from Leave where emp_id="+employeeId;
		return session.createQuery(hql).list();
		
	}
	
	@Override
	public boolean giveFeedback(Feedback feedback) {
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();
		try {
			session.save(feedback);
			txn.commit();
			return true;
		} catch (Exception e) {
			txn.rollback();
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public List<Feedback> getMyFeedback(int empId) {
		Session session = factory.openSession();
		String hql = "from Feedback  where emp_id=:eid order by feedbackId desc";
		return session.createQuery(hql).setParameter("eid", empId).list();
	}
	
	@Override
	public List<Announcement> getAnnouncements() {
		Session session = factory.openSession();
		String hql = "from Announcement";
		return session.createQuery(hql).list();
	}

	@Override
	public List<Announcement> empDashAnnouncement() {
		Session session = factory.openSession();
		String hql = "from Announcement order by annDate desc 2 ";		
		return session.createQuery(hql).list();
	
	}

	@Override
	public boolean applyProject(int projectId, Employee employee) {
		Session session = factory.openSession();
		
		Transaction txn = session.beginTransaction();
		try {
			Project project = (Project) session.get(Project.class, projectId);
			ProjectApplication projectApplication=new ProjectApplication();
			projectApplication.setProject(project);
			projectApplication.setEmp(employee);
			projectApplication.setStatus("Pending");
			employee.getAppliedFor().add(projectApplication);
		
			project.getProjApplication().add(projectApplication);
			session.merge(employee);
			session.merge(project);
			txn.commit();
			return true;
		} catch (Exception e) {
			txn.rollback();
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<ProjectApplication> viewApplicationStatus(Employee employee) {
		Session session = factory.openSession();
	
		String hql = " from ProjectApplication where emp_emp_id="+employee.getEmpId();
		
		return session.createQuery(hql).list();
	}

}
