package entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="leave")
@SequenceGenerator(sequenceName="l_seq",name="leaveSeq")
public class Leave {
	
	@Id
	@Column(name="l_id")
	@GeneratedValue(generator="leaveSeq")
	private int leaveId;
	
	@Column(name="l_from_date")
	private Date fromDate;
	
	@Column(name="l_to_date")
	private Date toDate;
	
	@Column(name="l_status")
	private String status;
	
	@Column(name="l_reason")
	private String reason;
	
	@Column(name="l_type")
	private String leaveType;

	@ManyToOne
	@JoinColumn(name="emp_id")
	private Employee emp;

	public int getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

}
