package service;

import java.util.List;
import java.util.Map;

import bean.ForgetBean;
import bean.LoginBean;
import bean.SalaryBean;
import entity.Employee;
import entity.Project;

public interface UserService {

	Employee authenticate(LoginBean login);

	boolean validate(ForgetBean forget);

	boolean changePass(LoginBean emp);

	SalaryBean viewSalary(int id);
	
	List<Project> viewProjects();
}
