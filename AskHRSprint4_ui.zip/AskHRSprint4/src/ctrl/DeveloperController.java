package ctrl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.ProjectApplication;
import service.DeveloperService;

@Controller
public class DeveloperController {

	@Autowired
	private DeveloperService service;

	@RequestMapping(value = "leave.do" ,method={RequestMethod.POST})
	public String applyLeave(@RequestParam("fromDate") String sFromDate, @RequestParam("toDate") String sToDate,
			@RequestParam("reason") String reason, @RequestParam("leaveType") String leaveType, HttpSession session) {
		Employee emp = (Employee) session.getAttribute("Employee");
		Leave leave = new Leave();
		Date fromdate = null;
		Date toDate = null;
		System.out.println(sFromDate);
		System.out.println(sToDate);
		try {
			fromdate = new SimpleDateFormat("yyyy-MM-dd").parse(sFromDate);
			toDate = new SimpleDateFormat("yyyy-MM-dd").parse(sToDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		leave.setFromDate(fromdate);
		leave.setToDate(toDate);
		leave.setLeaveType(leaveType);
		leave.setReason(reason);
		leave.setEmp(emp);

		System.out.println(leave.getFromDate());
		System.out.println(leave.getToDate());

		service.applyLeave(leave);

		return "empdashboard";
	}

	@RequestMapping("empViewLeaveStatus.do")
	public String viewLeaveStatus(HttpSession session, Map model) {
		// check for leave pending date<current and change status to pending
		Employee employee = (Employee) session.getAttribute("Employee");
		int employeeId = employee.getEmpId();
		List<Leave> leaves=service.viewLeaveStatus(employeeId);
		if(leaves.isEmpty())
			model.put("NoLeaves", "No leaves to display");
		else model.put("LeaveList",leaves);
		return "empViewLeaveStatus";
	}
	

	@RequestMapping(value="feedback.do", method= {RequestMethod.POST})
	public String giveFeedback(Feedback feedback,Map model, HttpSession session)  {
		
		
		
		Employee employee = (Employee) session.getAttribute("Employee");
		System.out.println(employee.getEmpId());
		feedback.setEmp(employee);
		
		service.giveFeedback(feedback);
		model.put("feedbacks", feedback);
		return "empdashboard";
			
	}

	
	@RequestMapping("viewfeedback.do")
	public String getMyFeedback(Map model, HttpSession session) {
		Employee emp=(Employee)session.getAttribute("Employee");
		model.put("feedback",service.getMyFeedback(emp.getEmpId()));
		return "viewfeedback";
		
	}
	
	@RequestMapping("viewannouncement.do")
	public String getAnnouncements(Map model) {
		model.put("viewannouncement", service.getAnnouncements());
		return "viewannouncement";
	}
	
	@RequestMapping("devdashboard.do")
	public String empDashAnnouncement(Map model) {
		model.put("viewtopannouncement", service.empDashAnnouncement());
		return "devdashboard";
	}
	
	@RequestMapping("apply.do")
	public String applyProject(@RequestParam("id")String projectId , HttpSession session ) {
		
		Employee employee = (Employee) session.getAttribute("Employee");
		
		service.applyProject(projectId , employee);
		return "redirect:/viewprojects.do";
	}

	@RequestMapping("viewapplicationstatus.do")
	public String viewApplicationStatus(Map model,HttpSession session) {
		Employee employee=(Employee)session.getAttribute("Employee");
		model.put("ApplicationStatus", service.viewApplicationStatus(employee));
		return "viewapplicationstatus";
	}
}
