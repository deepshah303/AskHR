document.write('\
\
    <!-- <h1 align="center">AskHR</h1> -->\
    <img src="images/Logo.jpg" style="width:7%;height:7%;display:block; margin: 0 auto">\
    <hr size="3" color="midnightblue">\
\
');