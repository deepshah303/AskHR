document.write('\
\
    <!-- <h1 align="center">AskHR</h1> -->\
    <img src="images/Logo.jpg" style="width:7%;height:7%;display:block; margin: 0 auto">\
    <p align="center"><a href="empdashboard.jsp">Dashboard</a> | <a href="empGiveFeedback.jsp">Give Feedback</a> | <a href="salaryStatus.jsp">Salary Status</a> | <a href="empApplyForLeaves.jsp">Apply for Leaves</a></p>\
    <hr size="3" color="midnightblue">\
\
');

