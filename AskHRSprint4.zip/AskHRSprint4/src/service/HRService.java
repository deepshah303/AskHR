package service;

import java.util.List;

import bean.RecruitBean;
import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.Project;
import entity.ProjectApplication;

public interface HRService {

	List<Leave> getLeaves();

	boolean acceptLeave(int leaveId);

	boolean rejectLeave(int leaveId);

	List<Feedback> viewFeedback();

	List<Employee> getEmployees(String skill);

	Employee recruitEmployee(RecruitBean recruit, Employee emp);

	Employee searchEmployee(int empid);

	boolean makeAnnouncement(Announcement announcement);

	List<Announcement> viewAnnouncements();

	List<ProjectApplication> viewApplications();

	boolean acceptApplication(int empId, int projId);

	boolean rejectApplication(int empId, int projId);

	boolean persist(Employee employee);

}
