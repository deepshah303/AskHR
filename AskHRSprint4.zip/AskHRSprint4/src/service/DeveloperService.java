package service;

import java.util.List;

import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.ProjectApplication;

public interface DeveloperService {

	boolean applyLeave(Leave leave);

	boolean getAnnouncement(Announcement announcement);

	List<Leave> viewLeaveStatus(int employeeId);

	boolean giveFeedback(Feedback feedback);

	List<Feedback> getMyFeedback(int empId);
	
	List<Announcement> getAnnouncements();
	
	List<Announcement> empDashAnnouncement();

	boolean applyProject(String projectId, Employee employee);

	List<ProjectApplication> viewApplicationStatus(Employee employee);

}
