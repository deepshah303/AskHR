package repo;

import java.util.List;

import bean.ForgetBean;
import bean.LoginBean;
import entity.Employee;
import entity.Project;

public interface UserRepo {

	Employee authenticate(LoginBean login);

	boolean validate(ForgetBean forget);

	boolean changePass(LoginBean emp);

	int getSal(int id);
	
	List<Project> viewProjects();
}
