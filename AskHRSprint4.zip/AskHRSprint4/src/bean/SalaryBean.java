package bean;

public class SalaryBean {
	double salary;

	double inhand;
	double other;
	double pf;
	double gratuity;
	double basicSal;
	double hra;
	double conveyance;
	double medical;
	double adhoc;
	double meal;
	double totalInhandSalary;

	

	double subTotalAMonthly;
	double subTotalAAnnual;
	double subTotalBMonthly;
	double subTotalBAnnual;
	double TotalAnnual;
	double TotalMonthly;
	double variablePay;
	double medicalPremium;
	double grandTotal;

	
	
	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getInhand() {
		return inhand;
	}

	public void setInhand(double inhand) {
		this.inhand = inhand;
	}

	public double getOther() {
		return other;
	}

	public void setOther(double other) {
		this.other = other;
	}

	public double getPf() {
		return pf;
	}

	public void setPf(double pf) {
		this.pf = pf;
	}

	public double getGratuity() {
		return gratuity;
	}

	public void setGratuity(double gratuity) {
		this.gratuity = gratuity;
	}

	public double getBasicSal() {
		return basicSal;
	}

	public void setBasicSal(double basicSal) {
		this.basicSal = basicSal;
	}

	public double getHra() {
		return hra;
	}

	public void setHra(double hra) {
		this.hra = hra;
	}

	public double getConveyance() {
		return conveyance;
	}

	public void setConveyance(double conveyance) {
		this.conveyance = conveyance;
	}

	public double getMedical() {
		return medical;
	}

	public void setMedical(double medical) {
		this.medical = medical;
	}

	public double getAdhoc() {
		return adhoc;
	}

	public void setAdhoc(double adhoc) {
		this.adhoc = adhoc;
	}

	public double getMeal() {
		return meal;
	}

	public void setMeal(double meal) {
		this.meal = meal;
	}

	public double getSubTotalAMonthly() {
		return subTotalAMonthly;
	}

	public void setSubTotalAMonthly(double subTotalAMonthly) {
		this.subTotalAMonthly = subTotalAMonthly;
	}

	public double getSubTotalAAnnual() {
		return subTotalAAnnual;
	}

	public void setSubTotalAAnnual(double subTotalAAnnual) {
		this.subTotalAAnnual = subTotalAAnnual;
	}

	public double getSubTotalBMonthly() {
		return subTotalBMonthly;
	}

	public void setSubTotalBMonthly(double subTotalBMonthly) {
		this.subTotalBMonthly = subTotalBMonthly;
	}

	public double getSubTotalBAnnual() {
		return subTotalBAnnual;
	}

	public void setSubTotalBAnnual(double subTotalBAnnual) {
		this.subTotalBAnnual = subTotalBAnnual;
	}

	public double getTotalAnnual() {
		return TotalAnnual;
	}

	public void setTotalAnnual(double totalAnnual) {
		TotalAnnual = totalAnnual;
	}

	public double getTotalMonthly() {
		return TotalMonthly;
	}

	public void setTotalMonthly(double totalMonthly) {
		TotalMonthly = totalMonthly;
	}

	public double getVariablePay() {
		return variablePay;
	}

	public void setVariablePay(double variablePay) {
		this.variablePay = variablePay;
	}

	public double getMedicalPremium() {
		return medicalPremium;
	}

	public void setMedicalPremium(double medicalPremium) {
		this.medicalPremium = medicalPremium;
	}

	public double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}
	
	public double getTotalInhandSalary() {
		return totalInhandSalary;
	}

	public void setTotalInhandSalary(double totalInhandSalary) {
		this.totalInhandSalary = totalInhandSalary;
	}
}
