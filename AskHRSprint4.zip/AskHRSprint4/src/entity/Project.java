package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(sequenceName="proj_seq",name="projSeq")
public class Project {

	@Id
	@GeneratedValue(generator="projSeq")
	@Column(name="proj_id")
	private int projectId;
	
	@Column(name="proj_name")
	private String projectName;
	
	@Column(name="emp_req")
	private int employeesRequired;
	
	@Column(name="skill_req")
	private String skillRequired;
	
	@Column(name="proj_status")
	private String status;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "paId.proj")
	private Set<ProjectApplication> projApplication = new HashSet();


	
	public Set<ProjectApplication> getProjApplication() {
		return projApplication;
	}

	public void setProjApplication(Set<ProjectApplication> projApplication) {
		this.projApplication = projApplication;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getEmployeesRequired() {
		return employeesRequired;
	}

	public void setEmployeesRequired(int employeesRequired) {
		this.employeesRequired = employeesRequired;
	}

	public String getSkillRequired() {
		return skillRequired;
	}

	public void setSkillRequired(String skillRequired) {
		this.skillRequired = skillRequired;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
