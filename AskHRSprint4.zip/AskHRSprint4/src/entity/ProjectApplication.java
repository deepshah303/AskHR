package entity;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "project_application")

public class ProjectApplication {
	
	@EmbeddedId
	private ProjAppID paId=new ProjAppID();
	
	@Column(name="status")
	private String status;

	public ProjAppID getPaId() {
		return paId;
	}

	public void setPaId(ProjAppID paId) {
		this.paId = paId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	@Transient
	public Project getProject() {
		return getPaId().getProj();
	}
	
	public void setProject(Project proj) {
		 getPaId().setProj(proj);
	}
	
	@Transient
	public Employee getEmp() {
		return getPaId().getEmp();
	}
	
	public void setEmp(Employee emp) {
		getPaId().setEmp(emp);
	}
}
