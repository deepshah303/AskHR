package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
@SequenceGenerator(sequenceName="f_seq", name="feedbackSeq")
public class Feedback {
	
	@Id
	@GeneratedValue(generator="feedbackSeq")
	@Column(name="f_id")
	private int feedbackId;
	
	@Column(name="f_content")
	private String feedbackContent;
	
	@Column(name="f_category")
	private String category;
	
	@ManyToOne
	@JoinColumn(name="emp_id")
	private Employee emp;
	

	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public Employee getEmp() {
		return emp;
	}
	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	public String getFeedbackContent() {
		return feedbackContent;
	}
	public void setFeedbackContent(String feedbackContent) {
		this.feedbackContent = feedbackContent;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	

}
