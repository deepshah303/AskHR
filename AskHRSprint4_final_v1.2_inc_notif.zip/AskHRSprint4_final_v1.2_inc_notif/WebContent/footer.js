document.write('\
\
<hr size="3" color="midnightblue">\
<p align="center"> &copy; Copyright 2020 | AskHR Limited</p>\
\
');