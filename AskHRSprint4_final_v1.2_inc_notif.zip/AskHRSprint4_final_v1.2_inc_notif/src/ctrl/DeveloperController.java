package ctrl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.ProjectApplication;
import service.DeveloperService;

@Controller
public class DeveloperController {

	@Autowired
	private DeveloperService service;

	@RequestMapping(value = "leave.do" ,method={RequestMethod.POST})
	public String applyLeave(Map model,@RequestParam("fromDate") String sFromDate, @RequestParam("toDate") String sToDate,
			@RequestParam("reason") String reason, @RequestParam("leaveType") String leaveType, HttpSession session) {
		Employee emp = (Employee) session.getAttribute("Employee");
		Leave leave = new Leave();
		Date fromdate = null;
		Date toDate = null;
		System.out.println(sFromDate);
		System.out.println(sToDate);
		try {
			fromdate = new SimpleDateFormat("yyyy-MM-dd").parse(sFromDate);
			toDate = new SimpleDateFormat("yyyy-MM-dd").parse(sToDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		leave.setFromDate(fromdate);
		leave.setToDate(toDate);
		leave.setLeaveType(leaveType);
		leave.setReason(reason);
		leave.setEmp(emp);

		System.out.println(leave.getFromDate());
		System.out.println(leave.getToDate());

		if(service.applyLeave(leave))
			model.put("LeavePrompt","Applied for leave successfully!");

		return "empdashboard";
	}

	@RequestMapping("empViewLeaveStatus.do")
	public String viewLeaveStatus(HttpSession session, Map model) {
		// check for leave pending date<current and change status to pending
		Employee employee = (Employee) session.getAttribute("Employee");
		int employeeId = employee.getEmpId();
		List<Leave> leaves=service.viewLeaveStatus(employeeId);
		if(leaves.isEmpty())
			model.put("NoLeaves", "No leaves to display");
		else model.put("LeaveList",leaves);
		return "empViewLeaveStatus";
	}
	

	@RequestMapping(value="feedback.do", method= {RequestMethod.POST})
	public String giveFeedback(Feedback feedback,Map model, HttpSession session)  {
		
		Employee employee = (Employee) session.getAttribute("Employee");
		System.out.println(employee.getEmpId());
		feedback.setEmp(employee);
		
		service.giveFeedback(feedback);
		model.put("FeedbackPrompt", "Feedback submitted succesfully!");
		
		return "empdashboard";
			
	}

	
	@RequestMapping("viewfeedback.do")
	public String getMyFeedback(Map model, HttpSession session) {
		Employee emp=(Employee)session.getAttribute("Employee");
		List<Feedback> feedbacks=service.getMyFeedback(emp.getEmpId());
		if(feedbacks.isEmpty())
			model.put("NoFeedback","No feedbacks given!");
		model.put("feedback",feedbacks);
		return "viewfeedback";
		
	}
		
	@RequestMapping("viewannouncement.do")
	public String getAnnouncements(Map model) {
		List<Announcement> announcements=service.getAnnouncements();
		if(announcements.isEmpty())
			model.put("NoAnn","No announcements made yet!");
		model.put("viewannouncement", announcements);
		return "viewannouncement";
	}
	
	@RequestMapping("devdashboard.do")
	public String empDashAnnouncement(Map model) {
		model.put("viewtopannouncement", service.empDashAnnouncement());
		return "devdashboard";
	}
	
	@RequestMapping("apply.do")
	public String applyProject(@RequestParam("id")String projectId , HttpSession session,Map model ) {
		
		Employee employee = (Employee) session.getAttribute("Employee");
		
		if(service.applyProject(projectId , employee))
			model.put("ProjApp","Applied for project successfully!");
		else model.put("ProjApp", "Already applied for this project" );
		return "empdashboard";
	}

	@RequestMapping("viewapplicationstatus.do")
	public String viewApplicationStatus(Map model,HttpSession session) {
		Employee employee=(Employee)session.getAttribute("Employee");
		model.put("ApplicationStatus", service.viewApplicationStatus(employee));
		return "viewapplicationstatus";
	}
}
