package ctrl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import bean.RecruitBean;
import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.Project;
import entity.ProjectApplication;
import service.HRService;

@Controller
public class HRController {
	@Autowired
	private HRService service;

	@RequestMapping("approve.do")
	public String viewLeaves(Map model, HttpSession session) {
		List<Leave> leaves = service.getLeaves();
		if (leaves.isEmpty()) {
			model.put("NoLeaves", "No leaves to display! ");
			/* return "hrdashboard"; */
		}
		model.put("Leaves", leaves);
		return "hrapproveleaves";
	}

	@RequestMapping("acceptLeave.do")
	public String acceptLeave(@RequestParam("id") int lid, Map model, HttpSession session) {

		if (service.acceptLeave(lid)) {
			model.put("decision", "Done");
			// System.out.println();
			return "redirect:/approve.do";
		} else {
			model.put("error", "Failed");
			return "hrapproveleaves";
		}

	}

	@RequestMapping("rejectLeave.do")
	public String rejectLeave(@RequestParam("id") int lid, Map model, HttpSession session) {
		if (service.rejectLeave(lid)) {
			model.put("decision", "Done");
			return "redirect:/approve.do";
		} else {
			model.put("error", "Failed");
			return "hrapproveleaves";
		}
	}

	@RequestMapping("hrviewfeedback.do")
	public String viewFeedback(Map model, HttpSession session) {
		List<Feedback> feeds = service.viewFeedback();
		if (feeds.isEmpty()) {
			model.put("NoFeedback", "No feedbacks to display!");
			/* return "hrdashboard"; */
		}
		model.put("viewFeedback", feeds);
		return "hrviewfeedback";

	}
	
	@RequestMapping(value = "hrmakeannouncement.do", method = { RequestMethod.POST })
	public String makeAnnouncement(Announcement announcement, Map model, HttpSession session) {
		Employee employee = (Employee) session.getAttribute("Employee");
		announcement.setEmp(employee);
		// System.out.println("a");
		service.makeAnnouncement(announcement);
		model.put("AnnPrompt", "Announcement made succesfully!");
		// System.out.println("b");
		return "hrdashboard";
	}

	@RequestMapping("hrviewannouncement.do")
	public String viewAnnouncements(Map model, HttpSession session) {
		// Announcement announcement = (Announcement)
		// session.getAttribute(announcement);
		List<Announcement> announcements = service.viewAnnouncements();
		if (announcements.isEmpty())
			model.put("NoAnnouncements", "No announcements to display!");
		model.put("viewannouncement", announcements);
		return "hrviewannouncement";
	}


	

	@RequestMapping("hire.do")
	public String viewEmployees(Map model, @RequestParam("skill") String skill, @RequestParam("id") String id,
			RecruitBean recruit, HttpSession session) {

		recruit.setSkill(skill);

		recruit.setEmpResult(service.getEmployees(skill));
		// System.out.println(recruit.getEmpResult());
		if (recruit.getEmpResult().isEmpty()) {
			model.put("NoEmp", "No Trainees with this skill");
			/* return "redirect:/viewprojects.do"; */
		} else {
			recruit.setProjectId(Integer.parseInt(id));
			session.setAttribute("RecruitBean", recruit);
			model.put("TraineeList", recruit.getEmpResult());
		}
		return "viewemployees";

	}

	@RequestMapping("viewempprofile.do")
	public String viewEmployee(HttpSession session, @RequestParam("id") String empId) {
		int empid = Integer.parseInt(empId);
		Employee emp = service.searchEmployee(empid);

		session.setAttribute("Recruit", emp);

		return "empprofile";
	}
	
	@RequestMapping("viewemployee.do")
	public String viewProfile(Map model,HttpSession session, @RequestParam("empid") String empId , @RequestParam("projid") String  projId) {
		int empid = Integer.parseInt(empId);
		
		Employee emp = service.searchEmployee(empid);

		session.setAttribute("Profile", emp);
		model.put("projId",projId);
		return "acceptapplicationprofile";
	}

	@RequestMapping("recruit.do")
	public String recruitEmployee(HttpSession session, Map model) {

		RecruitBean recruit = (RecruitBean) session.getAttribute("RecruitBean");

		service.recruitEmployee(recruit, (Employee)session.getAttribute("Recruit"));
		session.setAttribute("RecruitPrompt", "Hired successfully!");

		
		return "redirect:/viewprojects.do";
	}
	
	@RequestMapping("search.do")
	public String searchEmployee(@RequestParam("searchBar") String employeeid, Map model, HttpSession session) {
		int empid = Integer.parseInt(employeeid);
		Employee employee = service.searchEmployee(empid);
		if (employee == null) {
			
			model.put("NoEmp", "No employee found");
			/*session.setAttribute("NoSearchResult", "No employee found");*/
			/* model.put("Prompt", "no"); */
			/*return "hrdashboard";*/
		}
		model.put("Search", employee);
		return "profile";
	}
	
	@RequestMapping("viewapplications.do")
	public String viewApplications(Map model) {
		
		List<ProjectApplication> applications=service.viewApplications();
		if(applications.isEmpty())
			model.put("NoApp","No applications to display!");
		model.put("Applications", applications);
		return "hrapproveproject";
	}

	@RequestMapping("acceptapplication.do")
	public String acceptApplication(@RequestParam("empid") int empId,@RequestParam("projid") int projId, Map model, HttpSession session) {

		String msg=service.acceptApplication(empId,projId);
		
		if (msg.equalsIgnoreCase("Hired successfully!")) {
			session.setAttribute("AppPrompt", msg);
			// System.out.println();
			return "redirect:/viewapplications.do";
		} else if(msg.equalsIgnoreCase("Requirements are already met!")){
			session.setAttribute("AppPrompt", msg);
			return "redirect:/viewapplications.do";
		}else {
			model.put("AppPrompt", msg);
			return "hrapproveproject";
		}

	}

	@RequestMapping("rejectapplication.do")
	public String rejectApplication(@RequestParam("empid") int empId,@RequestParam("projid") int projId, Map model, HttpSession session) {
		if (service.rejectApplication(empId,projId)) {
			session.setAttribute("AppPrompt", "Rejected successfully!");
			return "redirect:/viewapplications.do";
		} else {
			model.put("error", "Failed");
			return "hrapproveproject";
		}
	}
	
	@RequestMapping(value = "add.do", method = { RequestMethod.POST })
	public String addEmployee(@RequestParam("empName") String empName,
			@RequestParam("empEmail") String empEmail,
			
			@RequestParam("dob") String sdob,
			@RequestParam("empCity") String empCity,
			@RequestParam("contact") String empContact,
			@RequestParam("doj") String sdoj,
			@RequestParam("empType") String empType,
		
			@RequestParam("empSkill") String empSkill,
			
			@RequestParam("empSecurityAns") String empSecurityAns,
			@RequestParam("empSalary") int empSalary,
			Map model, HttpSession session) {

		Employee emp = new Employee();

		Date dob = null;
		Date doj = null;

		System.out.println("sdob = " + sdob);
		System.out.println("sdoj = " + sdoj);
		
		try {
			dob = new SimpleDateFormat("yyyy-MM-dd").parse(sdob);
			doj = new SimpleDateFormat("yyyy-MM-dd").parse(sdoj);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		emp.setContact(empContact);
		emp.setDob(dob);
		emp.setDoj(doj);
		emp.setEmpCity(empCity);
		emp.setEmpEmail(empEmail);

		emp.setEmpName(empName);
		emp.setEmpPassword("Newuser123");
		emp.setProject(null);
		emp.setEmpSalary(empSalary);
		emp.setEmpSecurityAns(empSecurityAns);
		emp.setEmpSkill(empSkill);
		emp.setEmpStatus("Benched");
		emp.setEmpType(empType);
		
		System.out.println("Dob = " + emp.getDob());
		System.out.println("Doj = " + emp.getDoj());

		if (service.persist(emp)) {
			model.put("AddPrompt", "Employee added successfully");
			
		} else {
			model.put("Invalid", "An error occured while adding employee, please try again!");
			
		}
		return "hrdashboard";
	}


}
