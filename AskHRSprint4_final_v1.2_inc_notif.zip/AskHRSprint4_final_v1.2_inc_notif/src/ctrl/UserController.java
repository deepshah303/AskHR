package ctrl;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import bean.ForgetBean;
import bean.LoginBean;
import bean.SalaryBean;
import entity.Employee;
import entity.Project;
import service.HRService;
import service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;
	
	@Autowired
	private HRService hrService;

	@RequestMapping(value="login.do",method= {RequestMethod.POST}) // method that is run when login form is submit
	public String checkLogin(LoginBean login, Map model, HttpSession session)
	// session injected for remembering the user for a session
	{
		Employee emp = service.authenticate(login); // calling service's authenticate method
		if (emp != null) { // if authentication is right
			session.setAttribute("Employee", emp);//setting user details for the session
			if(emp.getEmpType().equalsIgnoreCase("hr"))
					return "hrdashboard";
			else return "empdashboard";// go to dashboard page
		} else {
			// if unsuccessful
			model.put("Prompt", "User ID/Password is incorrect");
			return "home"; // remain on home page
		}

	}

	@RequestMapping(value="forget.do",method= {RequestMethod.POST})
	public String forgetPass(ForgetBean forget, Map model, HttpSession session) {
		if (service.validate(forget)) {
			//if userId and email match
			session.setAttribute("Id", forget.getEmpId()); // setting attribute Id of session, to send to change page
			// model.put("ID", forget.getUserId());
			return "change";
		} else {
			//if userId and email doesnt match
			model.put("Invalid", " ID & Answer does not match");
			return "forget";
		}

	}

	@RequestMapping("change.do")
	public String changePass(LoginBean change, Map model, HttpSession session) {
		change.setEmpId((Integer) session.getAttribute("Id")); //getting attribute Id from session
		if (service.changePass(change)) {
			//if password changed successfully
			model.put("Prompt", "Password successfully changed");
			return "home";
		} else {
			
			model.put("Invalid", "Passwords does not match");
			return "change";
		}

	}

	

	@RequestMapping("logout.do")
	public String logout(Map model, HttpSession session) {
		session.invalidate();
		model.put("Prompt", "Logout successfully");
		return "home";
	}
	
	@RequestMapping("salary.do")
	public String viewSalary(SalaryBean salary,Map model,HttpSession session) {
		Employee emp=(Employee)session.getAttribute("Employee");
		salary=service.viewSalary(emp.getEmpId());
		session.setAttribute("Salary", salary);
		return "salary";
	}
	
	@RequestMapping("viewprojects.do")
	public String viewProjects(Map model) {
			List<Project> projects=service.viewProjects(); 
		if(projects.isEmpty())
			model.put("NoProj", "No Open Projects!");
		model.put("Projects", projects);
		return "viewprojects";
	}

}


