package service;

import java.util.Base64;
import java.util.List;
import java.util.Base64.Encoder;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bean.ForgetBean;
import bean.LoginBean;
import bean.SalaryBean;
import entity.Employee;
import entity.Project;
import repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo repo;

	@Override
	public Employee authenticate(LoginBean login) {
		Encoder enc = Base64.getEncoder();
		login.setEmpPassword(enc.encodeToString(login.getEmpPassword().getBytes()));
		return repo.authenticate(login);
	}

	@Override
	public boolean validate(ForgetBean forget) {
		Encoder enc = Base64.getEncoder();
		forget.setAnswer(enc.encodeToString(forget.getAnswer().getBytes()));
		return repo.validate(forget);
	}

	@Override
	public boolean changePass(LoginBean emp) {
		Encoder enc = Base64.getEncoder();
		emp.setEmpPassword(enc.encodeToString(emp.getEmpPassword().getBytes()));
		return repo.changePass(emp);
	}

	@Override
	public List<Project> viewProjects() {
		return repo.viewProjects();
	}

	@Override
	public SalaryBean viewSalary(int id) {
		// business logic
		int salary = repo.getSal(id);
		// Map model;
		// calc

		SalaryBean salaryInfo = new SalaryBean();

		salaryInfo.setTotalInhandSalary(0.9 * salary);
		double inhand = salaryInfo.getTotalInhandSalary() / 12;
		salaryInfo.setInhand(inhand);
		salaryInfo.setOther(0.10 * salary);
		salaryInfo.setPf(0.04 * inhand);
		salaryInfo.setGratuity(0.02 * inhand);
		salaryInfo.setBasicSal(0.33 * inhand);
		salaryInfo.setHra(0.10 * inhand);
		salaryInfo.setConveyance(0.05 * inhand);
		salaryInfo.setMedical(0.06 * inhand);
		salaryInfo.setAdhoc(0.34 * inhand);
		salaryInfo.setMeal(0.06 * inhand);
		salaryInfo.setSubTotalAMonthly(salaryInfo.getBasicSal() + salaryInfo.getHra() + salaryInfo.getConveyance()
				+ salaryInfo.getMedical() + salaryInfo.getAdhoc() + salaryInfo.getMeal());

		salaryInfo.setSubTotalAAnnual(salaryInfo.getSubTotalAMonthly() * 12);
		salaryInfo.setSubTotalBMonthly(salaryInfo.getPf() + salaryInfo.getGratuity());
		salaryInfo.setSubTotalBAnnual(salaryInfo.getSubTotalBMonthly() * 12);
		salaryInfo.setTotalAnnual(salaryInfo.getSubTotalAAnnual() + salaryInfo.getSubTotalBAnnual());
		salaryInfo.setTotalMonthly(salaryInfo.getSubTotalAMonthly() + salaryInfo.getSubTotalBMonthly());
		salaryInfo.setVariablePay(0.90 * salaryInfo.getOther());
		salaryInfo.setMedicalPremium(0.10 * salaryInfo.getOther());
		salaryInfo.setGrandTotal(
				salaryInfo.getTotalAnnual() + salaryInfo.getVariablePay() + salaryInfo.getMedicalPremium());

		return salaryInfo;
	}

}
