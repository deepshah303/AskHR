package service;

import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bean.RecruitBean;
import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.Project;
import entity.ProjectApplication;
import repo.HRRepo;
import repo.UserRepo;

@Service
public class HRServiceImpl implements HRService {

	@Autowired
	private HRRepo repo;
	
	
	@Override
	public boolean persist(Employee employee) {
		Encoder encoder = Base64.getEncoder();
		employee.setEmpPassword(encoder.encodeToString(employee.getEmpPassword().getBytes()));
		employee.setEmpSecurityAns(encoder.encodeToString(employee.getEmpSecurityAns().getBytes()));
		
		return repo.persist(employee);
	}

	@Override
	public List<Leave> getLeaves() {
		return repo.getLeaves();
	}


	@Override
	public boolean acceptLeave(int leaveId) {
		return repo.acceptLeave(leaveId);
	}


	@Override
	public boolean rejectLeave(int leaveId) {
		return repo.rejectLeave(leaveId);
	}
	
	@Override
	public List<Feedback> viewFeedback() {
		return repo.viewFeedback();
	}


	@Override
	public List<Employee> getEmployees(String skill) {
		return repo.getEmployees(skill);
	}


	@Override
	public Employee recruitEmployee(RecruitBean recruit, Employee emp) {
		return repo.recruitEmployee(recruit, emp);
	}




	@Override
	public Employee searchEmployee(int empid) {
		return repo.searchEmployee(empid);
	}

	@Override
	public boolean makeAnnouncement(Announcement announcement) {
		announcement.setAnnDate(new Date());
		return repo.makeAnnouncement(announcement);
	}

	@Override
	public List<Announcement> viewAnnouncements() {
		return repo.viewAnnouncements();
	}


	@Override
	public List<ProjectApplication> viewApplications() {
		return repo.viewApplications();
	}


	@Override
	public String acceptApplication(int empId, int projId) {
		return repo.acceptApplication( empId,  projId);
	}


	@Override
	public boolean rejectApplication(int empId, int projId) {
		return repo.rejectApplication( empId,  projId);
	}
	
}
