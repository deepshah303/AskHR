package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.ProjectApplication;
import repo.DeveloperRepo;

@Service
public class DeveloperServiceImpl implements DeveloperService {

	@Autowired
	private DeveloperRepo repo;
	
	@Override
	public boolean applyLeave(Leave leave) {
		leave.setStatus("Pending");	
		return repo.applyLeave(leave);
	}

	@Override
	public boolean getAnnouncement(Announcement announcement) {
		return false;
	}

	@Override
	public List<Leave> viewLeaveStatus(int employeeId) {
		return repo.viewLeaveStatus(employeeId);
	}


	@Override
	public boolean giveFeedback(Feedback feedback) {
		//feedback.setFeedbackId(feedbackId);
		return repo.giveFeedback(feedback);

	}

	@Override
	public List<Feedback> getMyFeedback(int empId) {
		return repo.getMyFeedback(empId);
	}
	
	@Override
	public List<Announcement> getAnnouncements() {
		return repo.getAnnouncements();
	}

	@Override
	public List<Announcement> empDashAnnouncement() {
		return repo.empDashAnnouncement();
	}

	@Override
	public boolean applyProject(String projectId, Employee employee) {
		int projId = Integer.parseInt(projectId);
		return repo.applyProject(projId, employee);
	}

	@Override
	public List<ProjectApplication> viewApplicationStatus(Employee employee) {
		return repo.viewApplicationStatus(employee);
	}

}