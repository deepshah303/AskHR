package repo;

import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Base64.Encoder;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bean.RecruitBean;
import entity.Announcement;
import entity.Employee;
import entity.Feedback;
import entity.Leave;
import entity.Project;
import entity.ProjectApplication;

@Repository
public class HRRepoImpl implements HRRepo {

	@Autowired
	private SessionFactory factory;

	@Override
	public boolean persist(Employee employee) {
		Session session=factory.openSession();
		Transaction trx=session.beginTransaction();
		try {
			session.save(employee);
			trx.commit();
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			trx.rollback();
			return false;
		}
	}

	@Override
	public List<Leave> getLeaves() {
		Session session = factory.openSession();
		String hql = "from Leave where LOWER(status) ='pending'";

		Query query = session.createQuery(hql);
		List<Leave> leaves =query.list();
		session.close();
		return leaves;
	}

	@Override
	public boolean acceptLeave(int levId) {
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();

		try {
			String hql = "update Leave set status ='approved' where leaveId = " + levId;
			Query query = session.createQuery(hql);
			query.executeUpdate();
			// System.out.println("Commit");
			txn.commit();
			session.close();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			// System.out.println("Rollback");
			txn.rollback();
			return false;
		}

	}

	@Override
	public boolean rejectLeave(int levId) {
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();

		try {
			String hql = "update Leave set status ='disapproved' where leaveId = " + levId;
			Query query = session.createQuery(hql);
			query.executeUpdate();
			// System.out.println("Commit");
		
			txn.commit();
			session.close();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			// System.out.println("Rollback");
			txn.rollback();
			return false;
		}

	}

	@Override
	public List<Feedback> viewFeedback() {
		Session session = factory.openSession();
		String hql = "from Feedback";
		List<Feedback> feedback=session.createQuery(hql).list();
		session.close();
		return feedback;
	}

	@Override
	public List<Employee> getEmployees(String skill) {
		Session session = factory.openSession();
		String hql = "from Employee where LOWER(empType)='trainee' AND LOWER(empSkill)=:empskill";
		List<Employee> empList=session.createQuery(hql).setParameter("empskill", skill.toLowerCase()).list();
		session.close();
		return empList;
	}

	@Override
	public Employee recruitEmployee(RecruitBean recruit, Employee emp) {

		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();
		Project project = (Project) session.get(Project.class, recruit.getProjectId());

		if (project.getEmployeesRequired()==0)
			return null;
		else {

			try {

				emp.setEmpType("Developer");
				emp.setEmpStatus("Billable");
				emp.setProject(project);
				session.merge(emp);
				project.setEmployeesRequired(project.getEmployeesRequired() - 1);
				if (project.getEmployeesRequired() == 0)
					project.setStatus("Closed");
				
				
				
				
				session.merge(project);
				
				
				
				txn.commit();
				
				session.close();
				return emp;
			} catch (Exception e) {
				txn.rollback();
				e.printStackTrace();
				return null;
			}
		}

	}

	@Override
	public Employee searchEmployee(int empId) {
		Session session = factory.openSession();
		Employee emp=(Employee)session.get(Employee.class, empId);
		return emp;
	}
	
	@Override
	public boolean makeAnnouncement(Announcement announcement) {
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();
		try {
			session.save(announcement);
			txn.commit();
			session.close();
			return true;
		} catch (Exception e) {
			txn.rollback();
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public List<Announcement> viewAnnouncements() {
		Session session = factory.openSession();
		String hql = "from Announcement order by annDate desc";
		List<Announcement> ann=session.createQuery(hql).list();
		session.close();
		return ann;
	}

	@Override
	public List<ProjectApplication> viewApplications() {
		Session session = factory.openSession();
		String hql = "from ProjectApplication where LOWER(status) ='pending'";

		List<ProjectApplication> projects = session.createQuery(hql).list();
		return projects;
		
	}

	@Override
	public String acceptApplication(int empId, int projId) {
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();

		try {
			Employee emp=(Employee)session.get(Employee.class, empId);
			Project proj=(Project)session.get(Project.class, projId);
			if(proj.getEmployeesRequired()!=0) {
			String hql1 = "update ProjectApplication set status ='accepted' where emp_emp_id = " + empId+" and proj_proj_id="+projId;
			Query query = session.createQuery(hql1);
			query.executeUpdate();
			
			emp.setEmpStatus("Billable");
			emp.setProject(proj);
			emp.setEmpType("Developer");
			proj.setEmployeesRequired(proj.getEmployeesRequired()-1);
			if (proj.getEmployeesRequired() == 0)
				proj.setStatus("Closed");
			//session.update(emp);
			session.merge(proj);
			// System.out.println("Commit");
			txn.commit();
			session.close();
			return "Hired successfully!";
			}
			else return "Requirements are already met!";
		} catch (HibernateException e) {
			e.printStackTrace();
			// System.out.println("Rollback");
			txn.rollback();
			return "Error occured";
		}

	}
	
	@Override
	public boolean rejectApplication(int empId, int projId) {
		Session session = factory.openSession();
		Transaction txn = session.beginTransaction();

		try {
			String hql = "update ProjectApplication set status ='rejected' where emp_emp_id = " + empId+" and proj_proj_id="+projId;
			Query query = session.createQuery(hql);
			query.executeUpdate();
			// System.out.println("Commit");
			txn.commit();
			session.close();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			// System.out.println("Rollback");
			txn.rollback();
			return false;
		}

	}

}
