package entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Formula;
import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="Employee")
@SequenceGenerator(sequenceName="emp_seq",name="empSeq")
public class Employee {
	
	@Id
	@GeneratedValue(generator="empSeq")
	@Column(name="emp_id")
	private int empId;
	
	@Column(name="emp_name")
	private String empName;
	
	@Column(name="emp_email")
	private String empEmail;
	
	@Column(name="emp_password")
	private String empPassword;
	
	@Column(name="emp_dob")
	private Date dob;
	
	@Column(name="emp_city")
	private String empCity;
	
	@Column(name="emp_contact")
	private String contact;
	
	
	@Column(name="emp_doj")
	private Date doj;
	
	@Column(name="emp_type")
	private String empType;
	
	@Column(name="emp_status")
	private String empStatus;
	
	@Column(name="emp_skill")
	private String empSkill;
	
	@Formula("(select count(*) from Announcement)")
	private int notification;
	

	
	public int getNotification() {
		return notification;
	}
	public void setNotification(int notification) {
		this.notification = notification;
	}
	@Column(name="emp_security_ans")
	private String empSecurityAns;
	
	@Column(name="emp_salary")
	private int empSalary;

	@ManyToOne
	@JoinColumn(name="proj_id")
	private Project project;

	@OneToMany(fetch=FetchType.LAZY,mappedBy="paId.emp")
	private Set<ProjectApplication> appliedFor=new HashSet<ProjectApplication>();
	
	public Set<ProjectApplication> getAppliedFor() {
		return appliedFor;
	}
	public void setAppliedFor(Set<ProjectApplication> appliedFor) {
		this.appliedFor = appliedFor;
	}
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpPassword() {
		return empPassword;
	}
	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getEmpCity() {
		return empCity;
	}
	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public String getEmpType() {
		return empType;
	}
	public void setEmpType(String empType) {
		this.empType = empType;
	}
	public String getEmpStatus() {
		return empStatus;
	}
	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}
	public String getEmpSkill() {
		return empSkill;
	}
	public void setEmpSkill(String empSkill) {
		this.empSkill = empSkill;
	}
		public String getEmpSecurityAns() {
		return empSecurityAns;
	}
	public void setEmpSecurityAns(String empSecurityAns) {
		this.empSecurityAns = empSecurityAns;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	
	
	
}
