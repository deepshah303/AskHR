package entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Formula;


@Entity
@Table(name="announcement")
@SequenceGenerator(sequenceName="a_seq", name="annSeq")

public class Announcement {
	@Id
	@GeneratedValue(generator="annSeq")
	@Column(name="a_id")
	private int annId;

	@Column(name="a_content")
	private String annContent;
	
	@Column(name="a_date")
	private Date annDate;
	
	@Column(name="a_category")
	private String annCategory;

	public String getAnnCategory() {
		return annCategory;
	}
	
	@Formula("(select count(*) from Announcement)")
	private int notification1; 

	public int getNotification1() {
		return notification1;
	}

	public void setNotification1(int notification1) {
		this.notification1 = notification1;
	}

	public void setAnnCategory(String annCategory) {
		this.annCategory = annCategory;
	}

	@ManyToOne
	@JoinColumn(name="emp_id")
	private Employee emp;

	public int getAnnId() {
		return annId;
	}

	public void setAnnId(int annId) {
		this.annId = annId;
	}

	public String getAnnContent() {
		return annContent;
	}

	public void setAnnContent(String annContent) {
		this.annContent = annContent;
	}

	public Date getAnnDate() {
		return annDate;
	}

	public void setAnnDate(Date annDate) {
		this.annDate = annDate;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

}
